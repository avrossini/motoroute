# MotoRoute Planner — guia do projeto para Claude Code

App de planejamento de viagens de moto de longa distância. Mobile (iOS/Android) + Web, mesma conta, mesmo backend. Stack pretendida: **React Native / Expo** (mobile + web a partir do mesmo código) + **Supabase** (Postgres, Auth, Row Level Security) + APIs externas (Google Maps Directions, Google Places, WeatherAPI, Google Geocoding).

Escopo atual: **usuário único por viagem**. Não existe modelo de colaboração/múltiplos membros — isso foi avaliado e descartado. Não reintroduzir tabelas, papéis (owner/editor/viewer) ou lógica de grupo a menos que explicitamente solicitado.

## Estrutura deste pacote

```
docs/
  business-logic.md            regras de negócio — a fonte da verdade para qualquer decisão de comportamento
  database.md                  schema do Supabase: tabelas, colunas, RLS, índices, estratégia de cache
  mobile-ux.md                 diferenças de UX entre mobile (uso em campo) e web (planejamento)
  MotoRoute_MVP_Requisitos.docx  visão de produto original (contexto/motivação, nível mais alto que os .md acima)
prototype/
  index.html                   visualizador — abre os mockups em um frame de celular/browser, navegável
  mobile/*.html                mockup estático de cada tela mobile (HTML+CSS puro, sem framework)
  web/*.html                   mockup estático de cada tela web
  css/mobile.css, css/web.css  estilos dos mockups
```

## Ordem recomendada de leitura

1. `docs/MotoRoute_MVP_Requisitos.docx` — para entender o produto e o problema que ele resolve.
2. `docs/database.md` — schema completo; use como base para as migrations do Supabase (`supabase/migrations/`).
3. `docs/business-logic.md` — toda regra de negócio (validação de km entre paradas, alertas de clima/autonomia, ciclo de vida da viagem, check-in, hospedagem, cache). Qualquer lógica implementada deve seguir exatamente o que está aqui.
4. `docs/mobile-ux.md` — regras de UX específicas de plataforma (tamanhos de toque, dark mode na viagem ativa, o que existe só no mobile vs. só na web).
5. `prototype/index.html` — abra no browser para navegar visualmente por cada tela antes de implementar o componente correspondente. **Os mockups são referência visual/fluxo, não código de produção** — são HTML/CSS estático sem estado real, sem chamadas de API, sem framework. Servem para replicar layout, hierarquia visual e copy, não para reaproveitar como componente.

## Por que este pacote está organizado assim

- **Separação docs/ vs. prototype/** deixa claro o que é especificação (regras, schema — texto que o Claude Code deve ler integralmente antes de gerar código) e o que é referência visual (HTML estático — para consulta pontual tela a tela, não para leitura sequencial).
- **`database.md` tem front-matter `paths:`** apontando para `supabase/migrations/**`, `src/types/**`, `src/services/supabase*` — isso é intencional para quem usa convenções de "regras por caminho" (ex: arquivos de contexto do Claude Code/Cursor): o schema só é relevante quando se está tocando nesses diretórios.
- **Cada arquivo .md é autocontido e sem dependência de pastas externas** (não referenciam mais `fases.md` nem pastas de outra fase) — o projeto foi consolidado para ter uma única fonte de verdade, sem ramificações Fase 1/Fase 2.
- **Os mockups HTML usam nomes de arquivo previsíveis** (`nova-viagem-1.html`, `roteiro-lista.html`, `viagem-ativa.html` etc.) que correspondem 1:1 às telas descritas em `business-logic.md` e `mobile-ux.md` — facilita pedir "implemente a tela X" e ter um caminho claro do mockup à especificação.
- **Nada de protótipos legados ou versões antigas**: este pacote contém só a versão final/consolidada, para não confundir o agente com conteúdo descartado.

## Convenções a seguir ao gerar código

- RLS habilitado em toda tabela nova; política padrão é "usuário só acessa os próprios dados" (ver `database.md`).
- `uuid` como PK, `timestamptz` para qualquer timestamp.
- Nunca estimar distância/tempo de rota — sempre Google Directions API.
- Navegação ("Navegar até aqui") sempre redireciona para GPS externo (deep link mobile / nova aba web) — nunca implementar navegação dentro do app.
- Mobile = uso em campo (telas com fonte grande, alto contraste, sem scroll na tela de viagem ativa). Web = planejamento (mouse/teclado, layouts mais densos). Ver `mobile-ux.md` antes de portar qualquer tela entre plataformas.
